# Name:     VOIP Module
# Author:   Michael Bruno
# Descr:    Python module for VOIP implementation.

import sys,os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from voip_device import *